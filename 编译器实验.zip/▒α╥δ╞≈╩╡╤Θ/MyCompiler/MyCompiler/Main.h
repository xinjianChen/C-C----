﻿#include"SYN.h"
#include"LEX.h"

class Main
{
public:
	LEX lex;
	SYN syn;
	vector<int>state;
	vector<string>symbol;
	string cur;
	string act;
	string got;
	string LexTable[51];
public:
	Main()
	{
		memset(this->LexTable, 0, 51);
		this->LexTable[1] = "ID";
		this->LexTable[2] = "num";
		this->LexTable[38] = "str";
		this->LexTable[50] = "keyWord";
		this->LexTable[17] = "(";
		this->LexTable[18] = ")";
		this->LexTable[21] = "{";
		this->LexTable[22] = "}";
		this->LexTable[15] = "=";
		this->LexTable[28] = ";";
		this->LexTable[27] = ",";
		this->LexTable[33] = "<<";
		this->state.push_back(0);
	}
	void BulidLex(string TokenFile, string G3File);
	void LoadToken();
	string TypeToString(Token token);
	void BulidSyn(string FileName);
	void Analyze();;
	void AnalyzeToFile();
	~Main(){};
};