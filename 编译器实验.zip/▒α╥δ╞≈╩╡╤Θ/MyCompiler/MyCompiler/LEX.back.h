﻿/*
正规文法的保存
*/
struct G3
{
	char VN[20];
	char VT[20];
	char P[20][6];
	char S;
};

/*
自动机的保存
*/

struct M
{
	char K[51];
	char E[50];
	char f[100][9];
	char S;
	char Z[50];
};

static G3 LexG;
static M NFA;
static M DFA;
static char DriveTable[50][50] = { '\0' };

void InputGrammar();//输入文法

void GrammarToNFA();//文法转化为NFA

void NFAToDFA();//NFA转化为DFA

void DFAToLEX();