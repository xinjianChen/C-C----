﻿#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>

using namespace std;

static bool isParseVT = false;	//标记是否已经生成FIRSTVT集合和LASTVT集合
static bool isParseTABLE = false;	//标记是否已经生成优先关系表

/**************************************************************************************************************************
***************************************************************************************************************************
****************************  这  里  是  词  法  分  析  部  分  *********************************************************
***************************************************************************************************************************
**************************************************************************************************************************/


	/*
	枚举token的类型
	*/
typedef enum{
	TOKEN_UNKNOWN,		//未知
	TOKEN_NUM,			//数字
	TOKEN_STRING,		//字符串
	TOKEN_ID,			//标识符
	TOKEN_BYTE,			//字符

	/*
	保留字,包含C89的有32个关键字，　
	*/
	TOKEN_VOID,			//void
	TOKEN_SIGNED,		//signed
	TOKEN_UNSIGNED,		//unsigned
	TOKEN_SHORT,		//short
	TOKEN_LONG,			//long
	TOKEN_INT,			//int
	TOKEN_FLOAT,		//float
	TOKEN_DOUBLE,		//double
	TOKEN_CHAR,			//char
	TOKEN_ENUM,			//enum
	TOKEN_STRUCT,		//struct
	TOKEN_UNION,		//union
	TOKEN_TYPEDEF,		//typedef
	TOKEN_CONST,		//const
	TOKEN_VOLATILE,		//volatile
	TOKEN_AUTO,			//auto
	TOKEN_STATIC,		//static
	TOKEN_EXTERN,		//extern
	TOKEN_REGISTER,		//register
	TOKEN_SIZEOF,		//sizeof
	TOKEN_GOTO,			//goto
	TOKEN_RETURN,		//return
	TOKEN_BREAK,		//break
	TOKEN_CONTINUE,		//continue
	TOKEN_IF,			//if
	TOKEN_ELSE,			//else
	TOKEN_SWITCH,		//switch
	TOKEN_CASE,			//case
	TOKEN_DEFAULT,		//default
	TOKEN_DO,			//do
	TOKEN_WHILE,		//while
	TOKEN_FOR,			//for

	/*
	分界符
	*/
	TOKEN_COMMA,		//,
	TOKEN_COLON,		//:
	TOKEN_LEFT_PAREN,	//(
	TOKEN_RIGHT_PAREN,	//)
	TOKEN_LEFT_BRACKET,	//[
	TOKEN_RIGHT_BRACKET,//]
	TOKEN_LEFT_BRACE,	//{
	TOKEN_RIGHT_BRACE,	//}
	TOKEN_SEMICOLON,	//;
	TOKEN_DOT,			//.
	TOKEN_POINTER,		//->

	/*
	双目运算符
	*/
	TOKEN_ADD,			//+
	TOKEN_SUB,			//-
	TOKEN_MUL,			//*
	TOKEN_DIV,			///
	TOKEN_MOD,			//%
	
	/*
	单目
	*/
	TOKEN_SELF_ADD,		//++
	TOKEN_SELF_SUB,		//--

	/*
	赋值运算符
	*/
	TOKEN_ASSIGN,		//=

	/*
	位运算符
	*/
	TOKEN_BIT_AND,		//&
	TOKEN_BIT_OR,		//|
	TOKEN_BIT_NOT,		//~
	TOKEN_BIT_SHIFT_R,	//>>
	TOKEN_BIT_SHIFT_L,	//<<


	/*
	逻辑运算符
	*/
	TOKEN_LOGIC_AND,	//&&
	TOKEN_LOGIC_OR,		//||
	TOKEN_LOGIC_NOT,	//!

	/*
	关系运算符
	*/
	TOKEN_EQUAL,		//==
	TOKEN_NOT_EQUAL,	//!=
	TOKEN_GREATE,		//>
	TOKEN_GREATE_EQUAL,	//>=
	TOKEN_LESS,			//<
	TOKEN_LESS_EQUAL,	//<=
	TOKEN_QUESTION,		//?

	/*
	文件结尾符
	*/
	TOKEN_EOF			//EOF

}	TokenType;

	/*
	Tonken结构
	*/
typedef struct{
	TokenType type;
	const char* start;
	int length;
	int LineNo;
} Token;

	/*
	词法分析器结构体
	*/
struct Parser
{
	const char* sourceCode;
	const char* nextCharPtr;
	char curChar;
	Token curToken;
	Token preToken;
};

	/*
	关键字结构体
	*/
struct keyWordToken
{
	char* keyWord;
	int length;
	TokenType token;
};

	/*
	关键字查找表
	*/
struct keyWordToken keyWordList[]=
{
	{ "void",4 , TOKEN_VOID },
	{ "signed",6 , TOKEN_SIGNED },
	{ "unsigned", 8, TOKEN_UNSIGNED },
	{ "short",5 , TOKEN_SHORT },
	{ "long",4 , TOKEN_LONG },
	{ "int",3 , TOKEN_INT },
	{ "float",5 , TOKEN_FLOAT },
	{ "double",6 , TOKEN_DOUBLE },
	{ "char",4 , TOKEN_CHAR },
	{ "enum",4 , TOKEN_ENUM },
	{ "struct",6 , TOKEN_STRUCT },
	{ "union",5 , TOKEN_UNION },
	{ "typedef",7 , TOKEN_TYPEDEF },
	{ "const",5 , TOKEN_CONST },
	{ "volatile",8 , TOKEN_VOLATILE },
	{ "auto",4 , TOKEN_AUTO },
	{ "static",6 , TOKEN_STATIC },
	{ "extern",6 , TOKEN_EXTERN },
	{ "register",8 , TOKEN_REGISTER },
	{ "sizeof",6 , TOKEN_SIZEOF },
	{ "goto",4 , TOKEN_GOTO },
	{ "return",6 , TOKEN_RETURN },
	{ "break",5 , TOKEN_BREAK },
	{ "continue",8 , TOKEN_CONTINUE },
	{ "if",2 , TOKEN_IF },
	{ "else",4 , TOKEN_ELSE },
	{ "switch",6 , TOKEN_SWITCH },
	{ "case",4 , TOKEN_CASE },
	{ "default",7 , TOKEN_DEFAULT },
	{ "do",2 , TOKEN_DO },
	{ "while",5 , TOKEN_WHILE },
	{ "for",3 , TOKEN_FOR },
};

/*
类型说明结构体
*/
struct Explain
{
	TokenType type;
	char* explain;
	
};

/*
类型说明查找表
*/
struct Explain ExplainList[] = {
	{TOKEN_UNKNOWN ,"未知类型"  },
	{TOKEN_NUM ,"数字"  },
	{TOKEN_STRING ,"字符串"  },
	{TOKEN_ID , "变量"  },
	{TOKEN_BYTE , "字符"   },
	{TOKEN_VOID , "关键字"   },
	{TOKEN_SIGNED  , "关键字"   },
	{TOKEN_UNSIGNED  , "关键字"   },
	{TOKEN_SHORT  , "关键字"   },
	{TOKEN_LONG  , "关键字"   },
	{TOKEN_INT  , "关键字"   },
	{TOKEN_FLOAT  , "关键字"   },
	{TOKEN_DOUBLE  , "关键字"   },
	{TOKEN_CHAR  , "关键字"   },
	{TOKEN_ENUM  , "关键字"   },
	{TOKEN_STRUCT  , "关键字"   },
	{TOKEN_UNION  , "关键字"   },
	{TOKEN_TYPEDEF  , "关键字"   },
	{TOKEN_CONST  , "关键字"   },
	{TOKEN_VOLATILE  , "关键字"   },
	{TOKEN_AUTO  , "关键字"   },
	{TOKEN_STATIC  , "关键字"   },
	{TOKEN_EXTERN  , "关键字"   },
	{TOKEN_REGISTER  , "关键字"   },
	{TOKEN_SIZEOF  , "关键字"   },
	{TOKEN_GOTO  , "关键字"   },
	{TOKEN_RETURN  , "关键字"   },
	{TOKEN_BREAK  , "关键字"   },
	{TOKEN_CONTINUE  , "关键字"   },
	{TOKEN_IF  , "关键字"   },
	{TOKEN_ELSE  , "关键字"   },
	{TOKEN_SWITCH  , "关键字"   },
	{TOKEN_CASE  , "关键字"   },
	{TOKEN_DEFAULT  , "关键字"   },
	{TOKEN_DO  , "关键字"   },
	{TOKEN_WHILE  , "关键字"   },
	{TOKEN_FOR  , "关键字"   },
	{TOKEN_COMMA  , "逗号"   },
	{TOKEN_COLON  , "冒号"   },
	{TOKEN_LEFT_PAREN  , "左小括号"   },
	{TOKEN_RIGHT_PAREN  , "右小括号"   },
	{TOKEN_LEFT_BRACKET  , "右中括号"   },
	{TOKEN_RIGHT_BRACKET  , "右中括号"   },
	{TOKEN_LEFT_BRACE  , "右大括号"   },
	{TOKEN_RIGHT_BRACE  , "右大括号"   },
	{TOKEN_SEMICOLON  , "分号"   },
	{TOKEN_DOT  , "点"   },
	{TOKEN_POINTER  , "指针"   },
	{TOKEN_ADD  , "加"   },
	{TOKEN_SUB  , "减"   },
	{TOKEN_MUL  , "乘"   },
	{TOKEN_DIV  , "除"   },
	{TOKEN_SELF_ADD, "自加" },
	{TOKEN_SELF_SUB, "自减" },
	{TOKEN_MOD  , "取余"   },
	{TOKEN_ASSIGN  , "赋值"   },
	{TOKEN_BIT_AND  , "按位与"   },
	{TOKEN_BIT_OR  , "按位或"   },
	{TOKEN_BIT_NOT  , "按位非"   },
	{TOKEN_BIT_SHIFT_R  , "按位右移"   },
	{TOKEN_BIT_SHIFT_L  , "按位左移"   },
	{TOKEN_LOGIC_AND  , "逻辑与"   },
	{TOKEN_LOGIC_OR  , "逻辑或"   },
	{TOKEN_LOGIC_NOT  , "逻辑非"   },
	{TOKEN_EQUAL  , "相等"   },
	{TOKEN_NOT_EQUAL  , "不等"   },
	{TOKEN_GREATE  , "大于"   },
	{TOKEN_GREATE_EQUAL  , "大于等于"   },
	{TOKEN_LESS  , "小于"   },
	{TOKEN_LESS_EQUAL  , "小于等于"   },
	{TOKEN_QUESTION  , "问号"   },
	{TOKEN_EOF  , "文件结束符"   }
};

char lookAheadChar(Parser* parser);
void getNextToken(Parser* parser);
bool matchToken(Parser* parser, TokenType expected);
void consumeCurToken(Parser* parser, TokenType expected, const char* errMsg);
void consumeNextToken(Parser* parser, TokenType expected, const char* errMsg);
void LexAnalysis();


/**************************************************************************************************************************
***************************************************************************************************************************
****************************  下  面  是  语  法  分  析  部  分  *********************************************************
***************************************************************************************************************************
**************************************************************************************************************************/

/*

文法定义

<函数定义> -> <类型说明><声明符><复合语句>

<类型说明> -> void|char|int|float...

<声明符> -> <指针><直接声明符>|<直接声明符>
<指针> -> < * >
<直接声明符> -> <标识符（参数列表）> | <标识符（）>
<参数列表> -> <参数声明> | <参数列表 ,参数声明>
<参数声明> -> <说明符声明><标识符>

<复合语句> -> '{ ''}' | <{ 语句列表 }> | <{ <声明列表> <语句列表> }>

<语句列表> -> <语句> | <语句列表> <语句>
<语句> -> <声明语句> | <表达式语句> | <选择语句> | <循环语句> | <跳转语句>
<声明语句> -> <类型说明符> <标识符> <;> | <类型说明符> '= '<运算表达式;>
<跳转语句> -> <continue;> | <break;> | <return;> | <return表达式;>
<选择语句> -> 'if' '(' <表达式> ')' '{' < 语句列表> '}' | 
			'if' '(' <表达式> ')' '{' < 语句列表> '}' 'else' '{' <语句列表> '}'
<循环语句> -> 'while’'(' <表达式> ')' '{' <语句> '}'| 
			'for’'(' <表达式语句> ';' 表达式语句> ';' <表达式语句> ')’'{' <语句列表> '}'
<表达式语句> ->  <声明语句> | <赋值表达式> | <调用函数> | <运算表达式>
<赋值表达式> -> <标识符> '=' <运算表达式>
<>
<运算表达式> -> <数字> | <字符串> | <字符> | <标识符> | <四则运算>
<四则运算> -> 
*/

/*
能识别由加+ 减- 乘* 除/ 乘方^ 括号（）操作数所组成的
算术表达式，其文法如下： 
E→E+T|E-T|T 
T→T*F|T/F|F 
F→P^F|P 
P→(E)|i
*/

/*
产生式结构体P
*/
struct P
{
	char* left;//产生式右部
	char* right[20];
};

/*
文法G
*/
struct P G[]=
{
	{ "S", {"#E#",'\0'} },
	{ "E", { "E+T", "E-T", "T", '\0' } },
	{ "T", { "T*F", "T/F", "F", '\0' } },
	{ "F", {"P^F","P",'\0'} },
	{ "P", { "(E)", "i",'\0' } },
	{ '\0', { '\0' } }
};

/*
给出非终结符VT
*/
static char VT[] = { '+','-','*','/','^','(',')','i','#','\0' };

/*
生成和存储FIRSTVT集合和LASTVT集合,Euq用来保存包含关系
*/
static char FIRSTVT[20][20] = { 0 };
static char LASTVT[20][20] = { 0 };
static char EquFirst[20][20] = { 0 };
static char EquLast[20][20] = { 0 };

/*
存储优先关系表
*/
static char TABLE[20][20] = { { '\0','+', '-', '*', '/','^', '(', ')', 'i', '#','\0'} };



/*
链表，充当分析时的栈
*/
struct Node
{
	char curChar = '\0';
	Node* nextNote = NULL;
	Node* preNote = NULL;
	int len = 0;
};
static Node* top = NULL;
static Node* topVT = NULL;