﻿#include "SYN.h"

//判断是不是非终结符
bool SYN::isVN(string VN)
{
	vector<string>::iterator rs = find(newG.VN.begin(), newG.VN.end(), VN);
	if (rs != newG.VN.end())return true;
	return false;
}

//判断是不是终结符
bool SYN::isVT(string VT)
{
	vector<string>::iterator rs = find(newG.VT.begin(), newG.VT.end(), VT);
	if (rs != newG.VT.end())return true;
	return false;
}

//输入文法
void SYN::inputG(string FileName)
{
	ifstream fin(FileName);
	newG.VN.insert(newG.VN.begin(),"start");
	newG.VT.insert(newG.VT.begin(), "#");
	newG.left.insert(newG.left.begin(), "start");
	newG.right.insert(newG.right.begin(), "#");
	string line,str;
	getline(fin, line);
	cout << "Place Input VN:" << endl;
	while (line!="")
	{ 
		str = line.substr(0, line.find(",", 1));
		line = line.substr(str.length()+1);
		newG.VN.push_back(str);
		cout << str << " ";
	}
	cout <<endl<< "Place Input VT:" << endl;
	getline(fin, line);
	while (line!="")
	{
		str = line.substr(0, line.find(",", 1));
		line = line.substr(str.length()+1);
		newG.VT.push_back(str);
		cout << str << " ";
	}
	cout <<endl<< "Place Input G3:" << endl;
	while (getline(fin,line))
	{
		cout << line << endl;
		string str, left, right;
		str = line;
		if (str.find("->") == str.npos)break;
		left = str.substr(0, str.find("->"));
		right = str.substr(str.find("->") + 2, str.length());
		if (right == "@")newG.empty[left] = true;
		if(newG.empty.count(left)==0)newG.empty[left] = false;
		newG.left.push_back(left);
		newG.right.push_back(right);
	}
	newG.S = line;
	if (line == "")newG.S = newG.left.at(1);
	cout << "Place Input Start State:" << endl;
	cout << newG.S;
	fin.close();
	newG.right.erase(newG.right.begin());
	newG.right.insert(newG.right.begin(), "#"+newG.S+"#");

	//获取能推出空的非终结符 
	unsigned int i = 0, j = 0;
	for (i = 0; i < newG.right.size(); i++)
	{
		if (newG.empty[newG.left.at(i)])continue;
		if (isVN(newG.right.at(i)))
		{
			if (newG.empty[newG.right.at(i)]){
				newG.empty[newG.left.at(i)] = true;
				i = 0;
			}
		}
	}
	for (i = 0; i < newG.right.size(); i++)
	{
		if (newG.empty[newG.left.at(i)])continue;
		for (j = 0; j < newG.VT.size(); j++)
			if (newG.right.at(i).find(newG.VT.at(j)) != newG.right.at(i).npos)
				break;
		if (j == newG.VT.size())
		{
			string str=newG.right.at(i);
			for (j = 0; j < newG.VN.size(); j++)
			{
				if (str.find(newG.VN.at(j)) == str.npos)continue;
				if (newG.empty[newG.VN.at(j)])
					str.erase(str.find(newG.VN.at(j)), newG.VN.at(j).length());
				else
					break;
			}
			if (str == "")
			{
				newG.empty[newG.left.at(i)] = true;
				i = 0;
			}
		}
	}
}

//显示文法
void SYN::ShowG()
{
	cout << endl;
	vector<string>::iterator VN = newG.VN.begin();
	vector<string>::iterator VT = newG.VT.begin();
	cout << "VN:";
	for (; VN != newG.VN.end(); ++VN)cout << " "<<*VN;
	cout << endl;
	cout << "VT:";
	for (; VT != newG.VT.end(); ++VT)cout << " " << *VT;
	cout << endl;
	cout << "Start: " << newG.S << endl;
	cout << "G:" << endl;
	for (unsigned int i = 0; i < newG.left.size(); i++)
		cout << newG.left.at(i) << "->" << newG.right.at(i) << endl;
}


void SYN::initMap(map<string, bool>&obj)
{
	unsigned int j = 0;
	for (j = 0; j < newG.VT.size(); j++)
	{
		obj[newG.VT.at(j)] = false;
	}
}

//获得向前搜索符
void SYN::getFirst(string Ba, map<string, bool> &isFirst)
{
	string str = Ba;
	unsigned int i = 0,j=0;
	bool flag = false;
	if (str == "")return;
	for (j = 0; j < newG.VN.size(); j++)
	{
		if (str.find(newG.VN.at(j)) == 0 && !newG.empty[newG.VN.at(j)])
		{
			flag = true;
			for (i = 0; i < newG.left.size(); i++)
			{
				if (newG.left.at(i) != newG.VN.at(j) || newG.right.at(i).find(newG.left.at(i)) == 0)continue;
				string temp = newG.right.at(i);
				getFirst(temp,isFirst);

			}
		}
		else if (str.find(newG.VN.at(j)) == 0 && newG.empty[newG.VN.at(j)])
		{
			for (i = 0; i < newG.left.size(); i++)
			{
				flag = true;
				if (newG.left.at(i) != newG.VN.at(j))continue;
				string temp = newG.right.at(i);
				if (temp.find(newG.left.at(i)) == 0)temp.erase(0, newG.left.at(i).length());
				getFirst(temp, isFirst);
			}
			str.erase(0, newG.VN.at(j).length());
			getFirst(str, isFirst);
		}
	}
	if (flag){
		for (i = 0; i < newG.VN.size(); i++)
		{
			if (!newG.empty[newG.VN.at(i)])continue;
			while (Ba.find(newG.VN.at(i)) != Ba.npos)
				Ba.erase(Ba.find(newG.VN.at(i)), newG.VN.at(i).length());
		}
		if (Ba != "")isFirst["@"] = false;
	}
	else
	{
		for (j = 0; j < newG.VT.size(); j++){
			if (str.find(newG.VT.at(j)) == 0)
			{
				isFirst[newG.VT.at(j)] = true;
				return;
			}
		}
	}
}

void I::add(string left, string right, int dot,string locate, map<string, bool> forward)
{
	this->left.push_back(left);
	this->right.push_back(right);
	this->dot.push_back(dot);
	this->locate.push_back(locate);
	this->forward.push_back(forward);
}

//解析生成当前项目簇
void SYN::ParseI(I &Ii, string locate, map<string, bool> forward)
{
	vector<string>::iterator left = newG.left.begin();
	vector<string>::iterator right = newG.right.begin();
	for (; left != newG.left.end(); left++, right++)
	{
		if (*left != locate)continue;
		vector<string>::iterator it = newG.VT.begin();
		while (it != newG.VT.end() && 0 != (*right).find(*it))it++;
		if (it != newG.VT.end())
		{
			Ii.add(locate, *right, 0,(*it), forward);
		}
		else
		{
			it = newG.VN.begin();
			while (it != newG.VN.end() && 0 != (*right).find(*it))it++;
			Ii.add(locate, *right, 0, (*it), forward);
			if (it == newG.VN.end())continue;//出错
			string str = (*right).substr((*it).length());
			map<string, bool>nextForward;
			if (str == "")nextForward = forward;
			else
			{
				initMap(nextForward);
				getFirst(str, nextForward);
				nextForward["@"] = false;
			}
			if (*left!=*it)ParseI(Ii, *it, nextForward);
		}
	}
}

int SYN::hadI(I &Ii)
{
	unsigned int i = 0, j = 0;
	for (i = 0; i < Iset.size(); i++){
		if (Iset.at(i).left.size() != Ii.left.size())continue;
		if (Iset.at(i).right.size() != Ii.right.size())continue;
		if (Iset.at(i).dot.size() != Ii.dot.size())continue;
		if (Iset.at(i).locate.size() != Ii.locate.size())continue;
		if (Iset.at(i).forward.size() != Ii.forward.size())continue;
		bool flag = false;
		for (j = 0; j < Iset.at(i).left.size(); j++)if (Iset.at(i).left.at(j) != Ii.left.at(j))flag = true;
		for (j = 0; j < Iset.at(i).right.size(); j++)if (Iset.at(i).right.at(j) != Ii.right.at(j))flag = true;
		for (j = 0; j < Iset.at(i).dot.size(); j++)if (Iset.at(i).dot.at(j) != Ii.dot.at(j))flag = true;
		for (j = 0; j < Iset.at(i).locate.size(); j++)if (Iset.at(i).locate.at(j) != Ii.locate.at(j))flag = true;
		for (j = 0; j < Iset.at(i).forward.size(); j++)if (Iset.at(i).forward.at(j) != Ii.forward.at(j))flag = true;
		if (flag)continue;
		else return i;
	}
	return -1;
}

string SYN::findFirst(string str)
{
	vector<string>::iterator vt = this->newG.VT.begin();
	vector<string>::iterator vn = this->newG.VN.begin();
	for (; vn != this->newG.VN.end(); vn++)
		if (str.find(*vn) == 0)return *vn;
	for (; vt != this->newG.VT.end(); vt++)
		if (str.find(*vt) == 0)return *vt;
	return "";
}

//建立连接
void SYN::BulidConnect()
{
	map<string, bool> forward;
	this->initMap(forward);
	this->getFirst(*this->newG.left.begin(), forward);
	this->I0.add((*this->newG.left.begin()), (*this->newG.right.begin()), 1, this->newG.S, forward);
	this->ParseI(this->I0, this->newG.S, forward);
	this->Iset.push_back(this->I0);
	vector<I>::iterator Ii = this->Iset.begin();
	for (unsigned int n=0; n<this->Iset.size();n++)
	{
		vector<I>nextI;
		vector<string>pass;
		vector<string>::iterator vt = this->newG.VT.begin();
		vector<string>::iterator vn = this->newG.VN.begin();
		vector<string>::iterator left = this->Iset.at(n).left.begin();
		vector<string>::iterator right = this->Iset.at(n).right.begin();
		vector<int>::iterator dot = this->Iset.at(n).dot.begin();
		vector<string>::iterator locate = this->Iset.at(n).locate.begin();
		vector<map<string, bool>>::iterator forward = this->Iset.at(n).forward.begin();
		for (; vt != this->newG.VT.end(); vt++)
		{
			I tempI = *new I();
			bool flag = false;
			for (left = this->Iset.at(n).left.begin(),
				right = this->Iset.at(n).right.begin(), dot = this->Iset.at(n).dot.begin(), 
				locate = this->Iset.at(n).locate.begin(), forward = this->Iset.at(n).forward.begin()
				; right != this->Iset.at(n).right.end();left++, right++, dot++, locate++, forward++)
			{
				if (*locate == "#")continue;
				if (right->find(*vt, *dot) == *dot)
				{
					int nextdot = (*dot) + vt->length();
					string nextlocate = this->findFirst(right->substr(nextdot));
					tempI.add(*left, *right, nextdot, nextlocate, *forward);
					
					if (this->isVN(nextlocate))
					{	
						string str = right->substr(nextdot + nextlocate.length());
						map<string, bool>nextforward;
						initMap(nextforward);
						if (str != "")getFirst(str, nextforward);
						else nextforward = *forward;
						this->ParseI(tempI, nextlocate, nextforward);
					}
					flag = true;
				}
			}
			if (flag)
			{
				nextI.push_back(tempI);
				pass.push_back(*vt);
			}
		}
		for (; vn != this->newG.VN.end(); vn++)
		{
			I tempI = *new I();
			bool flag = false;
			for (left = this->Iset.at(n).left.begin(),
				right = this->Iset.at(n).right.begin(), dot = this->Iset.at(n).dot.begin(),
				locate = this->Iset.at(n).locate.begin(), forward = this->Iset.at(n).forward.begin()
				; right != this->Iset.at(n).right.end();left++, right++, dot++, locate++, forward++)
			{
				if (right->find(*vn, *dot) == *dot)
				{
					int nextdot = (*dot) + vn->length();
					string nextlocate = this->findFirst(right->substr(nextdot));
					tempI.add(*left, *right, nextdot, nextlocate, *forward);
					if (this->isVN(nextlocate))
					{
						string str = right->substr(nextdot + nextlocate.length());
						map<string, bool>nextforward;
						initMap(nextforward);
						if (str != "")getFirst(str, nextforward);
						else nextforward = *forward;
						this->ParseI(tempI, nextlocate, nextforward);
					}
					flag = true;
				}
			}
			if (flag)
			{
				nextI.push_back(tempI);
				pass.push_back(*vn);
			}
		}
		vector<I>::iterator nextIi = nextI.begin();
		vector<string>::iterator passi = pass.begin();
		for (; nextIi != nextI.end();passi++, nextIi++)
		{
			int num = this->hadI(*nextIi);
			if (num == -1)
			{
				this->Iset.at(n).link[*passi] = this->Iset.size();
				Iset.push_back(*nextIi);
			}
			if (num >= 0)this->Iset.at(n).link[*passi] = num;
		}
		
	}
}

void SYN::ShowIset()
{
	cout << endl;
	vector<I>::iterator Ii = Iset.begin();
	unsigned int i = 0, j = 0;
	for (; Ii != Iset.end(); Ii++, i++)
	{
		cout << "I" << i << ":" << endl;
		for (j = 0; j < (*Ii).left.size(); j++)
		{
			string right = (*Ii).right.at(j);
			right.insert((*Ii).dot.at(j), ".");
			right = right + ",";
			map<string, bool>::iterator it = (*Ii).forward.at(j).begin();
			while (it != (*Ii).forward.at(j).end())
			{
				if (it->second)break;
				else it++;
			}
			right += it->first;
			it++;
			while (it != (*Ii).forward.at(j).end())
			{
				if (it->second)
				{
					right += "/";
					right += it->first;
				}
				it++;
			}
			cout << (*Ii).left.at(j) << "->" << right << endl;
		}
		map<string, int>::iterator it = (*Ii).link.begin();
		for (; it != (*Ii).link.end();it++)
			cout << "I" << i << " pass " << it->first << " to I" << it->second << endl;
		cout << endl;

	}
}

//生成LR(1)分析表
void SYN::buidTable()
{
	this->BulidConnect();
	//this->connection(this->I0, 0);

	vector<I>::iterator Ii = Iset.begin();
	vector<string>::iterator vt = newG.VT.begin();
	vector<string>::iterator vn = newG.VN.begin();
	unsigned int i = 0, acc = 0;
	for (i = 0; i < Iset.size(); i++)
	{
		for (vt = newG.VT.begin(); vt != newG.VT.end(); vt++)
			if ((*vt) == "@")continue;
			else Action[i][(*vt)] = "  ";
		Action[i]["#"] = "  ";
		for ( vn = newG.VN.begin(); vn != newG.VN.end(); vn++)
			Goto[i][(*vn)] = "  ";
	}

	for (i = 0; Ii != Iset.end();i++, Ii++)
	{
		vector<string>Ri;
		vector<string>::iterator left = Ii->left.begin();
		vector<string>::iterator right = Ii->right.begin();
		map<string, int>::iterator link = Ii->link.begin();
		vector<string>::iterator locate = Ii->locate.begin();
		vector<map<string, bool> >::iterator forward = Ii->forward.begin();
		for (; left != Ii->left.end() && right != Ii->right.end() && locate != Ii->locate.end();
			left++, right++, locate++)
		{
			if ((*locate) == "#")acc = i;
			if ((*locate) == "")Ri.push_back((*left) + "->" + (*right));
			else Ri.push_back("  ");
		}
		for (vector<string>::iterator ri = Ri.begin();ri!=Ri.end() && forward != Ii->forward.end();ri++, forward++)
		{
			if (*ri == "  ")continue;
			map<string, bool>::iterator imap = forward->begin();
			for (; imap != forward->end(); imap++)
				if (imap->second)
					Action[i][imap->first] = (*ri);
		}
		for (; link != Ii->link.end(); link++)
		{
			if (isVT(link->first))Action[i][link->first] = "S" + to_string(link->second);
			else Goto[i][link->first] = to_string(link->second);
		}
	}
	Action[acc]["#"] = "acc";
}

void SYN::ShowTable()
{
	cout << endl;
	map<int, map<string, string> >::iterator act, got;
	act = Action.begin();
	got = Goto.begin();
	cout << "state" << "\t \t \t Action \t \t \t" << "\t Goto \t" << endl << endl;
	map<string, string>::iterator vt = act->second.begin();
	map<string, string>::iterator vn = got->second.begin();
	for (; vt != act->second.end(); vt++)cout << "\t" << vt->first ;
	for (; vn != got->second.end(); vn++)cout << "\t" << vn->first ;
	cout << endl << endl;;
	for (; act != Action.end() && got != Goto.end(); act++, got++)
	{
		cout << "  " << act->first << "  ";
		vt = act->second.begin();
		vn = got->second.begin();
		for (; vt != act->second.end(); vt++)cout << "\t" << vt->second ;
		for (; vn != got->second.end(); vn++)cout << "\t" << vn->second ;
		cout << endl;
	}
}

void SYN::TableToFile()
{
	ofstream fout;
	fout.open("SynTable.txt", ios::trunc);
	fout << endl;
	map<int, map<string, string> >::iterator act, got;
	act = Action.begin();
	got = Goto.begin();
	fout << "state" << "\t \t \t Action \t \t \t" << "\t Goto \t" << endl << endl;
	map<string, string>::iterator vt = act->second.begin();
	map<string, string>::iterator vn = got->second.begin();
	for (; vt != act->second.end(); vt++)fout << "\t" << vt->first;
	for (; vn != got->second.end(); vn++)fout << "\t" << vn->first;
	fout << endl << endl;;
	for (; act != Action.end() && got != Goto.end(); act++, got++)
	{
		fout << "  " << act->first << "  ";
		vt = act->second.begin();
		vn = got->second.begin();
		for (; vt != act->second.end(); vt++)fout << "\t" << vt->second;
		for (; vn != got->second.end(); vn++)fout << "\t" << vn->second;
		fout << endl;
	}
	fout.close();
}

//显示First集合
void SYN::ShowFirst(){
	cout << endl;
	map<string, bool>isFirst;
	unsigned int i = 0, j = 0;
	for (i = 0; i < newG.VN.size(); i++)
	{
		initMap(isFirst);
		string str = newG.VN.at(i);
		getFirst(str, isFirst);
		cout << "First (" << str << ") = {";
		for (j = 0; j < newG.VT.size(); j++)
		{
			if (isFirst[newG.VT.at(j)])cout << " " << newG.VT.at(j);
		}
		cout << " }" << endl;
	}
}

/*


E->E+T
E->T
T->T*F
T->F
F->(E)
F->i


S->L=R
S->R
L->aR
L->b
R->L

S->aAcBe
A->b
A->Ab
B->d

S->BB
B->aB
B->b

S->aAd
S->bAc
S->aec
S->bed
A->e

S->aH
H->aMd
H->d
M->Ab
M->@
A->aM
A->e


S->E$
E->T+E
E->T
T->x

S'->S
S->BB
B->aB
B->b

S->ABC
M->BD
M->AB
N->AcB
N->CD
A->B
B->b
B->@
C->c
C->@
D->d

S->AB
S->bC
A->@
A->b
B->@
B->aD
C->AD
C->b
D->aS
D->c

E->TA
A->+TA
A->@
T->FA
B->*FB
B->@
F->i
F->(E)




E->E+T
E->E-T
E->T
T->T*F
T->T/F
T->F
F->(E)
F->i

*/