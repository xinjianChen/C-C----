﻿#include"Main.h"

void Main::BulidLex(string TokenFile,string G3File)
{
	this->lex = *new LEX();
	this->lex.InputGrammar(G3File);
	this->lex.GrammarToNFA();
	this->lex.NFAToDFA();
	this->lex.ShowNFA();
	this->lex.ShowDFA();
	this->lex.GetTokenTable(TokenFile);
	this->lex.ShowTokenTable();
	ofstream fout;
	fout.open("LEX.txt", ios::binary | ios::trunc);
	fout << sizeof(this->lex) << '\n';
	fout.write((char*)&this->lex, sizeof(this->lex));
	fout.close();
}

void Main::LoadToken()
{
	this->lex.LoadToken();
	this->lex.ShowTokenTable();
}

void Main::BulidSyn(string FileName)
{
	this->syn = *new SYN();
	this->syn.inputG(FileName);
	this->syn.buidTable();
	this->syn.ShowG();
	this->syn.ShowFirst();
	this->syn.ShowIset();
	this->syn.ShowTable();
	this->syn.TableToFile();
	ofstream fout;
	fout.open("SYN.txt", ios::binary | ios::trunc);
	fout << sizeof(this->syn) << '\n';
	fout.write((char*)&this->syn, sizeof(this->syn));
	fout.close();
}

string Main::TypeToString(Token token)
{
	if (token.cur == "cout")return "cout";
	if (token.cur == "var")return"var";
	if (token.type >= 0 && token.type <= 50)return this->LexTable[token.type];
	else return "#";
}

 void Main::Analyze()
{
	cout << " Step" << "\t\t state" << "\t\t\t\t Symbol" << "\t\t\t CurChar" << "\t Action" << "\t\t Goto" << endl;
	unsigned int i = 0;
	vector<Token>::iterator token = this->lex.TokenTable.begin();
	if (token == this->lex.TokenTable.end())return;
	for (; token != this->lex.TokenTable.end(); token++, i++)
	{
		this->cur = this->TypeToString(*token);
		cout << "  " << i << "\t\t  ";
		vector<int>::iterator state = this->state.begin();
		while (state != this->state.end())cout << *state++ << ",";
		vector<string>::iterator symbol = this->symbol.begin();
		cout << "\t\t\t\t  ";
		while (symbol != this->symbol.end())cout << *symbol++;
		cout << "\t\t\t  " << this->cur;
		int curstate = this->state.back();
		if (this->syn.isVT(this->cur))
		{
			this->act = this->syn.Action[curstate][this->cur];
			if (this->act.find("->") != this->act.npos)
			{
				string left, right, symbolstr;
				left = this->act.substr(0, this->act.find("->"));
				right = this->act.substr(this->act.find("->") + 2);
				symbolstr = "";
				int len = this->symbol.size();
				int j = len - 1;
				for (; j >= 0; j--)
				{
					if (symbolstr.find(right) != symbolstr.npos)break;
					symbolstr = this->symbol.at(j) + symbolstr;
				}
				for (int k = 0; k < len - 1 - j; k++)
				{
					this->symbol.pop_back();
					this->state.pop_back();
				}
				curstate = this->state.back();
				this->cur = left;
				this->symbol.push_back(left);
			}
			else
			{
				this->state.push_back(atoi(this->act.substr(1).data()));
				this->symbol.push_back(this->cur);
			}
		}
		if(this->syn.isVN(this->cur))
		{
			this->got = this->syn.Goto[curstate][this->cur];
			int nextstate = atoi(this->got.data());
			this->state.push_back(nextstate);
			token--;
		}
		cout <<"\t\t  "<<this->act<<"\t\t "<<this->got<< endl;
		if (this->act == "acc")break;
	}
	if (this->act == "acc")cout << endl << "Successful!" << endl;
	else cout << endl << "Failed" << endl;
}

 void Main::AnalyzeToFile()
 {
	 ofstream fout;
	 fout.open("Analyze.txt", ios::trunc);
	 fout << " Step" << "\t\t state" << "\t\t\t\t Symbol" << "\t\t\t CurChar" << "\t Action" << "\t\t Goto" << endl;
	 unsigned int i = 0;
	 vector<Token>::iterator token = this->lex.TokenTable.begin();
	 if (token == this->lex.TokenTable.end())return;
	 for (; token != this->lex.TokenTable.end(); token++, i++)
	 {
		 this->cur = this->TypeToString(*token);
		 fout << "  " << i << "\t\t  ";
		 vector<int>::iterator state = this->state.begin();
		 while (state != this->state.end())fout << *state++ << ",";
		 vector<string>::iterator symbol = this->symbol.begin();
		 fout << "\t\t\t\t  ";
		 while (symbol != this->symbol.end())fout << *symbol++;
		 fout << "\t\t\t  " << this->cur;
		 int curstate = this->state.back();
		 if (this->syn.isVT(this->cur))
		 {
			 this->act = this->syn.Action[curstate][this->cur];
			 if (this->act.find("->") != this->act.npos)
			 {
				 string left, right, symbolstr;
				 left = this->act.substr(0, this->act.find("->"));
				 right = this->act.substr(this->act.find("->") + 2);
				 symbolstr = "";
				 int len = this->symbol.size();
				 int j = len - 1;
				 for (; j >= 0; j--)
				 {
					 if (symbolstr.find(right) != symbolstr.npos)break;
					 symbolstr = this->symbol.at(j) + symbolstr;
				 }
				 for (int k = 0; k < len - 1 - j; k++)
				 {
					 this->symbol.pop_back();
					 this->state.pop_back();
				 }
				 curstate = this->state.back();
				 this->cur = left;
				 this->symbol.push_back(left);
			 }
			 else
			 {
				 this->state.push_back(atoi(this->act.substr(1).data()));
				 this->symbol.push_back(this->cur);
			 }
		 }
		 if (this->syn.isVN(this->cur))
		 {
			 this->got = this->syn.Goto[curstate][this->cur];
			 int nextstate = atoi(this->got.data());
			 this->state.push_back(nextstate);
			 token--;
		 }
		 fout << "\t\t  " << this->act << "\t\t " << this->got << endl;
		 if (this->act == "acc")break;
	 }
	 if (this->act == "acc")fout << endl << "Successful!" << endl;
	 else fout << endl << "Failed" << endl;
	 fout.close();
 }


int main()
{
	
	string TokenFile = "charandnum.txt";//输入文件
	string G3File = "G3.txt";//3型文法
	Main test = *new Main();//构造实例
	string G2Name = "G2.txt";//LR(1)文法
	test.BulidLex(TokenFile,G3File);//构造次词法分析器
	//test.LoadToken();//加载先前Token
	test.BulidSyn(G2Name);//构造语法分析器
	test.Analyze();	//分析Token
	//test.AnalyzeToFile();//分析输出到文件
	return 0;
}

/*

正规文法
S->

S->L=R
S->R
L->aR
L->b
R->L

*/