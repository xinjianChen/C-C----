﻿#include"LEX.h"
#include<iostream>
#include<memory.h>
#include<string.h>

using namespace std;

void InputGrammar()
{
	memset(&LexG, '\0', sizeof(G3));
	cout << "请输入非终结符（最多50个）:";
	cin >> LexG.VN;
	cout << "请输入终结符（最多50个，@代表空）:";
	cin >> LexG.VT;
	cout << "请输入产生式（最多100个，输入00结束）:"<<endl;
	for (int i = 0; i < 50; i++){
		cin >> LexG.P[i];
		if (LexG.P[i][0] == '0'&&LexG.P[i][1]=='0'){
			LexG.P[i][0] = '\0';
			break;
		}
	}
	cout << "请输入开始符号:";
	cin >> LexG.S;
}

static void ShowG()
{
	InputGrammar();
	cout << "VN:{"<< LexG.VN <<"}"<< endl;
	cout << "VT:{"<< LexG.VT <<"}"<< endl;
	cout << "P:" << endl;
	for (int i = 0; LexG.P[i] != '\0'; i++){
		cout << LexG.P[i] << endl;
	}
	cout << "S:"<< LexG.S << endl;
}

static bool isVN(char ch)
{
	for (int i = 0; LexG.VN[i] != '\0'; i++){
		if (ch == LexG.VN[i])return true;
	}
	return false;
}

static bool isVT(char ch)
{
	for (int i = 0; LexG.VT[i] != '\0'; i++){
		if (ch == LexG.VT[i])return true;
	}
	return false;
}

void GrammarToNFA()
{

	memset(&NFA, '\0', sizeof(M));
	NFA.S = LexG.S;
	NFA.Z[0] = '$';
	NFA.K[0] = NFA.Z[0];
	for (int i = 0; LexG.VN[i] != '\0'; i++){
		NFA.K[i+1] = LexG.VN[i];
	}
	for (int i = 0; LexG.VT[i] != '\0'; i++){
		NFA.E[i] = LexG.VT[i];
	}
	for (int i = 0; LexG.P[i][0] != '\0'; i++){
		if (5 == strlen(LexG.P[i])){
			if (isVN(LexG.P[i][4])){
				NFA.f[i][0] = 'f';
				NFA.f[i][1] = '(';
				NFA.f[i][2] = LexG.P[i][0];
				NFA.f[i][3] = ',';
				NFA.f[i][4] = LexG.P[i][3];
				NFA.f[i][5] = ')';
				NFA.f[i][6] = '=';
				NFA.f[i][7] = LexG.P[i][4];
				NFA.f[i][8] = '\0';
				NFA.f[i + 1][0] = '\0';

			}
			else {
				cout << "不是右线正规文法!" << endl;
				return;
			}
		}
		else if (4 == strlen(LexG.P[i])){
			if (isVT(LexG.P[i][3])){
				NFA.f[i][0] = 'f';
				NFA.f[i][1] = '(';
				NFA.f[i][2] = LexG.P[i][0];
				NFA.f[i][3] = ',';
				NFA.f[i][4] = LexG.P[i][3];
				NFA.f[i][5] = ')';
				NFA.f[i][6] = '=';
				NFA.f[i][7] = NFA.Z[0];
				NFA.f[i][8] = '\0';
				NFA.f[i + 1][0] = '\0';

			}
			else {
				cout << "不是右线正规文法!" << endl;
				return;
			}
		}
		else{
			cout << "不是右线正规文法!" << endl;
			return;
		}
	}
	
}

static void ShowNFA()
{
	GrammarToNFA();
	cout << endl << "=======DFA=======" << endl;
	cout << "K:{" << NFA.K<< "}" << endl;
	cout << "E:{" << NFA.E << "}" << endl;
	cout << "f:" << endl;
	for (int i = 0; NFA.f[i][0]!= '\0'; i++){
		cout << NFA.f[i] << endl;
	}
	cout << "S:" << NFA.S << endl;
	cout << "Z:" << NFA.Z << endl;
}

static char* Closure(char T[],char VT)
{
	char* Ti = (char*)malloc(50);
	int n = 0;
	if (VT != '@')
	{
		for (int i = 0; T[i] != '\0'; i++)
		{
			for (int j = 0; NFA.f[j][0] != '\0'; j++)
			{
				if (NFA.f[j][2] != T[i])continue;
				if (NFA.f[j][4] != VT)continue;
				int k = 0;
				for (; k < n; k++)
				{
					if (Ti[k] == NFA.f[j][7])break;
				}
				if (k == n)
				{
					Ti[n] = NFA.f[j][7];
					n++;
				}
			}
		}
	}
	else
	{
		Ti[0] = T[0];
		n++;
	}
	Ti[n] = '\0';
	for (int i = 0; Ti[i] != '\0'; i++)
	{
		for (int j = 0; NFA.f[j][0] != '\0'; j++)
		{
			if (NFA.f[j][2] != Ti[i])continue;
			if (NFA.f[j][4] != '@')continue;
			int k = 0;
			for (; k < n; k++)
			{
				if (Ti[k] == NFA.f[j][7])break;
			}
			if (k == n)
			{
				Ti[n] = NFA.f[j][7];
				n++;
			}
		}
	}
	Ti[n] = '\0';
	return Ti;
}

static bool inSort(char VN, char K[])
{
	for (int i = 0; K[i] != '\0'; i++)
	{
		if (VN == K[i])return true;
	}
	return false;
}

static void SimplifyDFA()
{

	char K[21] = { '\0' }, f[100][9] = { '\0' }, Z[50] = { '\0' };
	char newK[21] = { '\0' }, newf[100][9] = { '\0' }, newZ[50] = { '\0' };
	char path[100][100] = { '\0' }; char T[50][50] = { '\0' };
	newf[0][0] = 'f'; newf[0][1] = '('; newf[0][2] = '@'; newf[0][3] = ',';
	newf[0][4] = '@'; newf[0][5] = ')'; newf[0][6] = '='; newf[0][7] = DFA.S;
	for (int i = 0; DFA.f[i][0] != '\0'; i++)
		for (int j = 0; DFA.f[i][j] != '\0'; j++)
			newf[i + 1][j] = DFA.f[i][j];
	for (int i = 0, k = 0; DFA.K[i] != '\0'; i++)
	{
		if (DFA.K[i] == DFA.S)
		{
			newK[i] = newK[0];
			newK[0] = DFA.K[i];
			k++;
			continue;
		}
		for (int j = 0; newf[j][0] != '\0'; j++)
		{
			if (newf[j][7] == DFA.K[i])
			{
				newK[i] = DFA.K[i];
				k++;
				break;
			}
		}
	}
	char * p1 = &T[0][0];
	char * p2 = &T[1][0];
	for (int i = 0; newK[i] != '\0'; i++)
	{
		if (inSort(newK[i], DFA.Z))*p1++ = newK[i];
		else *p2++ = newK[i];
		for (int j = 0,n=0; DFA.E[j] != '\0'; j++)
		{
			for (int k = 0; DFA.f[k][0] != '\0'; k++)
			{
				if (DFA.f[k][2] == newK[i] && DFA.f[k][4] == DFA.E[j])
				{
					path[i][n] = DFA.E[j];
					n++;
					path[i][n] = DFA.f[k][7];
					n++;
					break;
				}
			}
		}
	}
}

void NFAToDFA()
{
	char* Ti[100] = { '\0' };
	char* f[100] = { '\0' };
	bool isClosure[100] = { false };
	char T0[2] = { '\0' };
	T0[0] = NFA.S;
	Ti[0] = Closure(T0, '@');
	int n = 1,m=0;
	for (int i = 0; Ti[i] != '\0'; i++)
	{
		for (int j = 0; NFA.E[j] != '\0'; j++)
		{
			if (NFA.E[j] == '@')continue;
			char* temp = Closure(Ti[i], NFA.E[j]);
			int k = 0;
			for (; k < n; k++)if (strcmp(temp, Ti[k])==0)break;
			char* fi = (char*)malloc(9);
			fi[0] = 'f';
			fi[1] = '('; 
			fi[2] = i + 'A';
			fi[3] = ',';
			fi[4] = NFA.E[j];
			fi[5] = ')';
			fi[6] = '='; 
			fi[7] = (char)(k + 'A');
			fi[8] = '\0';
			f[m] = fi;
			m++;
			if (k == n)
			{
				Ti[n] = temp;
				n++;
			}
		}
	}
	memset(&DFA, '\0', sizeof(M));
	for (int i = 0, k = 0; Ti[i] != '\0'; i++)
	{
		DFA.K[i] = i + 'A';
		for (int j = 0; Ti[i][j] != '\0'; j++)
		{
			if (Ti[i][j] == NFA.Z[0])
			{
				DFA.Z[k] = i + 'A';
				k++;
				break;
			}
		}
	}
	for (int i = 0; NFA.E[i] != '\0'; i++)DFA.E[i] = NFA.E[i];
	DFA.S = 'A';
	for (int i = 0; f[i] != '\0'; i++)memcpy(DFA.f[i], f[i],9);
}

static void ShowDFA()
{
	NFAToDFA();
	cout << endl << "=======DFA=======" << endl;
	cout << "K:{" << DFA.K << "}" << endl;
	cout << "E:{" << DFA.E << "}" << endl;
	cout << "f:" << endl;
	for (int i = 0; DFA.f[i][0] != '\0'; i++){
		cout << DFA.f[i] << endl;
	}
	cout << "S:" << DFA.S << endl;
	cout << "Z:" << DFA.Z << endl;
}

static void CreateTable()
{
	memset(DriveTable, '\0',sizeof(DriveTable));
	for (int i = 0; DFA.K[i] != '\0'; i++)
	{
		DriveTable[0][i + 1] = DFA.K[i];
		DriveTable[i + 1][0] = DFA.K[i];
	}
	for (int i = 0; DFA.f[i][0] != '\0'; i++)
	{
		int x = 0,y=0;
		while (DFA.f[i][2] != DriveTable[y][0])y++;
		while (DFA.f[i][7] != DriveTable[0][x])x++;
		DriveTable[y][x] = DFA.f[i][4];

	}
}

static void ShowTable()
{
	cout << endl <<"========驱动表（DFA）========" << endl;
	int len = 1;
	while(DriveTable[0][len] != '\0')len++;
	cout << '\t'<<"|";
	for (int i = 0; i < len; i++)cout << "---" << "|";
	cout << endl;
	for (int i = 0; i < len; i++)
	{
		cout <<'\t'<< "|";
		for (int j = 0; j < len; j++)
		{
			cout <<" "<< DriveTable[i][j] << " |";
		}
		cout << endl<<'\t' << "|";
		for (int i = 0; i < len; i++)cout << "---" << "|";
		cout << endl;
	}
}

//int main()
//{
//	InputGrammar();
//	GrammarToNFA();
//	ShowNFA();
//	NFAToDFA();
//	ShowDFA();
//	CreateTable();
//	ShowTable();
//
//	return 0;
//}

/*
0->@1
1->@2
1->@4
2->a3
3->@6
4->b5
5->@6
6->@1
6->@7
0->@7
7->a8
8->b9
9->b10

S->aA
S->bB
S->@
A->aB
A->bA
B->aS
B->bA
B->@

1->a6
1->b3
2->a7
2->b3
3->a1
3->b5
4->a4
4->b6
5->a7
5->b3
6->a4
6->b1
7->a4
7->b2
5->@
6->@
7->@

S->lA
A->lA
A->l
S->dB
B->dB
B->d
S->+C
S->-C
S->*C
S->/C
C->@
S->,D
S->(D
S->)D
S->;D
D->@

@ld+*-/,();

S->iA
S->cC
S->bB
A->iA
A->@
C->cC
C->@
B->iB
B->bB
B->@

*/