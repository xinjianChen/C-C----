﻿#include<iostream>
#include<string>
#include<vector>
#include<map>
#include<cctype>
#include<fstream>
#include<memory>

using namespace std;

/*
3型文法类
*/
class G3
{
public:
	vector<string>VN;//非终结符
	vector<string>VT;//终结符
	vector<string>left;//产生式左部
	vector<string>right;//产生式右部
	string S;//开始符号
	bool isVN(string VN);
	bool isVT(string VT);
};

/*
自动机类
*/

class M
{
public:
	vector<string>K;//状态集
	vector<string>E;//字母表
	vector<string>Z;//终态集
	multimap<string, map<string, string> >f;//转换函数
	string S;//唯一初态
};


/*
Token类
*/
class Token
{
public:
	string cur;
	int line;
	int type;
};

static string KeyWord[] = { "asm", "do", "if", "return", "typedef", "auto", "double", "inline", "short", "typeid",
								"bool", "dynamic_cast", "int", "signed", "typename", "break", "else", "long", "union",
								"case", "enum", "mutable", "static", "unsigned", "catch", "explicit", "namespace",
								"static_cast", "using", "char", "export", "new", "struct", "virtual", "class", "extern",
								"operator", "switch", "void", "const", "false", "private", "template", "volatile",
								"const_cast", "float", "protected""this", "wchar_t", "continue", "for", "public", "throw",
								"while", "default", "friend", "register", "true", "delete", "goto", "reinterpret_cast", "try" };
/*
词法分析器类
*/
class LEX
{
public:
	G3 LexG;
	M NFA;
	M DFA;
	vector<map<string, bool>>Tset;

	vector<Token>TokenTable;

	void InputGrammar(string FileName);//输入文法

	bool isG3();//判断是否是三型文法

	void GrammarToNFA();//文法转化为NFA

	void Closure(map<string, bool> &Ti, string E);//求move(K,E)的空闭包

	void NFAToDFA();//NFA转化为DFA

	bool isKeyWord(string str);

	void GetNextToken(char* buff,int linenum);//获取下一个Token

	void GetTokenTable(string FileName);//获取整个Token表

	void LoadToken();//从文件载入token

	void ShowG();

	void ShowNFA();

	void ShowDFA();

	void ShowTokenTable();
};


