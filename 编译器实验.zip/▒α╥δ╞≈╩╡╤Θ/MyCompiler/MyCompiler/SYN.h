﻿#include<string>
#include<vector>
#include <iostream>
#include<memory>
#include<algorithm>
#include<map>
#include<queue>
#include<fstream>

using namespace std;

class G2
{
public:
	vector<string> VN;
	vector<string> VT;
	vector<string>left;
	vector<string>right;
	string S;
	map<string, bool>empty;
};

/*
项目簇类
*/
class I
{
public:
	vector<string>left;	//项目左部
	vector<string>right;	//项目右部
	vector<int>dot;		//点的位置
	vector<string>locate;	//点对应下一个符号
	vector<map<string,bool>>forward;	//向前搜索符
	map<string, int>link;	//连接

	void add(string left, string right, int dot, string locate, map<string, bool> forward);  //增加一条项目
};


class SYN
{
public:
	G2 newG;	//LR(1)文法
	I I0;	//I0项目集
	vector<I>Iset;	//保存项目集
	map<int, map<string,string> > Action;	//Action表
	map<int, map<string,string> > Goto;		//Goto表

	void inputG(string FinleName);		//读入文法

	void getFirst(string Ba, map<string, bool> &isFirst);		//获取First集	

	void ParseI(I &Ii, string locate, map<string, bool> forward);	//扩展项目

	string findFirst(string str);	//找下一个产生式点后面的终结符或非终结符对象

	void BulidConnect();	//对生成各个项目，并建立连接

	void buidTable();	//生成Action、Goto表

	void ShowG();

	void ShowFirst();

	void initMap(map<string, bool>&obj);	//初始化一个保存First集合的map

	void ShowIset();

	void ShowTable();

	bool isVN(string VN);

	bool isVT(string VT);

	int hadI(I &Ii);	//判断项目是否已经存在

	void TableToFile();	 //Action表Goto表输出到文件

}; 