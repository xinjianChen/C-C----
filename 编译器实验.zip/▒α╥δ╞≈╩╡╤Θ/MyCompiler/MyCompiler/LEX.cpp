﻿#include"LEX.h"

bool G3::isVN(string VN)
{
	vector<string>::iterator vn = this->VN.begin();
	for (; vn != this->VN.end(); vn++)
		if ((*vn) == VN)return true;
	return false;
}

bool G3::isVT(string VT)
{
	vector<string>::iterator vt = this->VT.begin();
	for (; vt != this->VT.end(); vt++)
		if ((*vt) == VT)return true;
	return false;
}

void LEX::InputGrammar(string FileName)
{
	ifstream fin(FileName);
	string line, str;
	getline(fin, line);
	cout << "Place Input VN:" << endl;
	while (line != "")
	{
		str = line.substr(0, line.find(",", 1));
		line = line.substr(str.length() + 1);
		this->LexG.VN.push_back(str);
		cout << str << " ";
	}
	cout << endl << "Place Input VT:" << endl;
	getline(fin, line);
	while (line != "")
	{
		str = line.substr(0, line.find(",", 1));
		line = line.substr(str.length() + 1);
		this->LexG.VT.push_back(str);
		cout << str << " ";
	}
	cout << endl << "Place Input G2:" << endl;
	while (getline(fin, line))
	{
		cout << line << endl;
		string str, left, right;
		str = line;
		if (str.find("->") == str.npos)break;
		left = str.substr(0, str.find("->"));
		right = str.substr(str.find("->") + 2, str.length());
		this->LexG.left.push_back(left);
		this->LexG.right.push_back(right);
	}
	this->LexG.S = line;
	if (line == "")this->LexG.S = this->LexG.left.at(1);
	cout << "Place Input Start State:" << endl;
	cout << this->LexG.S;
	fin.close();
}

bool LEX::isG3()
{
	vector<string>::iterator left = this->LexG.left.begin();
	vector<string>::iterator right = this->LexG.right.begin();
	while (left != this->LexG.left.end())
	{
		if (this->LexG.isVN((*left)))break;
		else left++;
	}
	if (left == this->LexG.left.end())return false;
	while (right != this->LexG.right.end())
	{
		string str = *right;
		right++;
		vector<string>::iterator vn = this->LexG.VN.begin();
		vector<string>::iterator vt = this->LexG.VT.begin();
		for (; vt != this->LexG.VT.end(); vt++)
		{
			if (str.find((*vt)) != str.npos)
			{
				str.erase(str.find((*vt)), (*vt).length());
				break;
			}
		}
		for (; vn != this->LexG.VN.end(); vn++)
		{
			if (str.find((*vn)) != str.npos)
			{
				str.erase(str.find((*vn)), (*vn).length());
				break;
			}
		}
		if (str != "")return false;
	}
	return true;
}

void LEX::GrammarToNFA()
{
	this->NFA.S = this->LexG.S;
	this->NFA.E = this->LexG.VT;
	this->NFA.K = this->LexG.VN;
	this->NFA.K.push_back("$");
	this->NFA.Z.push_back("$");
	vector<string>::iterator left = this->LexG.left.begin();
	vector<string>::iterator right = this->LexG.right.begin();
	for (; left != this->LexG.left.end() && right != this->LexG.right.end(); left++, right++)
	{
		vector<string>::iterator vn = this->LexG.VN.begin();
		vector<string>::iterator vt = this->LexG.VT.begin();
		int i = 0, j = 0;
		string str = *right;
		while (vn != this->LexG.VN.end())
		{
			i = str.find(*vn);
			if (i != str.npos)break;
			vn++;
		}
		if (i == str.npos)
		{
			map<string, string>temp;
			temp[*vt]= "$";
			this->NFA.f.insert(pair<string, map<string, string>>(*left, temp));
			continue;
		}
		str.erase(i, vn->length());
		while (vt != this->LexG.VT.end())
		{
			j = str.find(*vt);
			if (j != str.npos)break;
			vt++;
		}
		if (i == str.npos || j == str.npos)
		{
			cout << "Error, Grammar To NFA Filed" << endl;
			continue;
		}
		map<string, string>temp;
		temp[*vt]= *vn;
		this->NFA.f.insert(pair<string, map<string, string>>(*left, temp));
	}
}

void LEX::Closure(map<string, bool> &Ti, string E)
{
	map<string, bool>temp = Ti;
	if (E != "@")Ti.erase(Ti.begin(), Ti.end());
	bool respeat = true;
	while (respeat){
		respeat = false;
		map<string, bool>::iterator it = temp.begin();
		for (; it != temp.end(); it++){
			multimap<string, map<string, string> >::iterator f1 = this->NFA.f.begin();
			for (; f1 != this->NFA.f.end(); f1++)
			{
				if (f1->first == it->first)
				{
					map<string, string>::iterator f2 = f1->second.begin();
					if (f2->first == E && Ti.count(f2->second) == 0)
					{
						Ti[f2->second] = true;
						if(E=="@")temp[f2->second] = true;
						respeat = true;
						break;
					}
				}
				if (respeat)break;
			}
		}
	}
}

void LEX::NFAToDFA()//NFA转化为DFA
{
	map<string, bool>T0;
	T0[this->NFA.S] = true;
	this->Closure(T0, "@");
	Tset.push_back(T0);
	int ch = 10;
	string K0= "T" + to_string(ch);
	this->DFA.K.push_back(K0);
	unsigned int i = 0;
	for (; i < Tset.size(); i++)
	{
		
		vector<string>::iterator e = this->NFA.E.begin();
		for (; e != this->NFA.E.end(); e++)
		{
			if (*e == "@")continue;
			map<string, bool>Ti;
			Ti = Tset.at(i);
			map<string, bool>::iterator it = Ti.begin();
			while (it!= Ti.end())
			{
				multimap<string, map<string, string>>::iterator start, end;
				start = this->NFA.f.equal_range(it->first).first;
				end = this->NFA.f.equal_range(it->first).second;
				for (; start != end; start++)
				{
					map<string, string> f2 = start->second;
					if (f2.count(*e) != 0)break;
				}
				if (start != end)break;
				it++;
			}
			if (it == Ti.end())continue;
			this->Closure(Ti, *e);
			this->Closure(Ti, "@");
			unsigned int j = 0;
			while (j<Tset.size() && Ti != Tset.at(j) )j++;
			string Ki = "T" + to_string(ch + i);
			string Kj = "T" + to_string(ch + j);
			map<string, string> temp;
			temp[*e] = Kj;
			this->DFA.f.insert(pair<string, map<string, string>>(Ki, temp));
			if (j == Tset.size())
			{
				Tset.push_back(Ti);
				this->DFA.K.push_back(Kj);
				vector<string>::iterator z = this->NFA.Z.begin();
				while (z != this->NFA.Z.end() && Ti.count(*z) == 0)z++;
				if (z != this->NFA.Z.end())this->DFA.Z.push_back(Kj);
			}
		}
	}
	this->DFA.E = this->NFA.E;
	this->DFA.S = this->DFA.K.at(0);
}

/*
通过判断ASII码把ch转换成统一的表示字符
*/
static char GetChar(char ch)
{
	if (isalpha(ch))return 'a';
	if (isdigit(ch))return 'i';
	if (ispunct(ch))return ch;
	if (isspace(ch))return '0';
	return '$';
}

bool LEX::isKeyWord(string str)
{
	int len = 61;
	for (int i = 0; i < len; i++)
		if (KeyWord[i] == "str")return true;
	return false;
}

void LEX::GetNextToken(char* buff,int linenum)
{
	while (*buff != '\0'){
		Token token = *new Token();
		token.line = linenum;
		token.cur = "";
		string state = this->DFA.S;
		while (*buff != '\0')
		{
			multimap<string, map<string, string>>::iterator start, end;
			start = this->DFA.f.equal_range(state).first;
			end = this->DFA.f.equal_range(state).second;
			for (; start != end; start++)
			{
				map<string, string> f2 = start->second;
				string ch = "";
				ch += GetChar(*buff);
				if (!this->LexG.isVT(ch) && !this->LexG.isVN(ch))
				{
					cout << "errer ,nunknow symbol on line:" << linenum << ":'" << buff << endl;
					while (!this->LexG.isVT(ch) && !this->LexG.isVN(ch))
					{
						ch += GetChar(*buff);
						buff++;
						if (*buff == '\0')return;
					}
				}
				if (f2.count(ch)== 0)continue;
				token.cur += *buff;
				state = f2[ch];
				break;
			}
			if (start == end)break;
			buff++;
		}
		while (*buff!='\0' && GetChar(*buff) == '0')buff++;
		token.type = atoi(state.substr(1).data()) - 10;
		if (token.type == 38)
			if (isKeyWord(token.cur))token.type = 50;
		TokenTable.push_back(token);
	}
}

void LEX::GetTokenTable(string FileName)
{
	int linenum = 0;
	ifstream fin(FileName);
	if (!fin)exit(-1);
	string line;
	bool flag = false;
	while (getline(fin, line))
	{
		linenum++;
		if (line.find("//") != line.npos)line.erase(line.find("//"));
		if (line.find("/*") != line.npos)
		{
			line.erase(line.find("/*"));
			flag = true;
		}
		if (line.find("*/") != line.npos)
		{
			flag = false;
			line.erase(0, line.find("*/") + 2);
		}
		if (flag)continue;
		line.erase(0, line.find_first_not_of(" "));
		line.erase(line.find_last_not_of(" ") + 1);
		line.erase(0, line.find_first_not_of('\t'));
		line.erase(line.find_last_not_of('\t') + 1);
		line.erase(0, line.find_first_not_of('\r'));
		line.erase(line.find_last_not_of('\r') + 1);
		line.erase(0, line.find_first_not_of('\n'));
		line.erase(line.find_last_not_of('\n') + 1);
		if (line.empty())continue;
		Token token = *new Token();
		this->GetNextToken((char*)line.data(),linenum);
	}
	Token endtoken;
	endtoken.cur = "#";
	endtoken.line = -1;
	endtoken.type = -1;
	this->TokenTable.push_back(endtoken);
	fin.close();
	fstream fToken;
	fToken.open("TokenTable.txt", fstream::binary | fstream::out | fstream::trunc);
	if (!fToken.is_open())exit(-1);
	vector<Token>::iterator to = this->TokenTable.begin();
	for (; to != this->TokenTable.end(); to++)
		fToken << to->cur << '\n' << to->line << '\n' << to->type << '\n';
	fToken.close();
}

void LEX::LoadToken()
{
	this->TokenTable.erase(this->TokenTable.begin(), this->TokenTable.end());
	ifstream fin("TokenTable.txt");
	if (!fin)exit(-1);
	string line;
	Token token = *new Token();
	while (getline(fin, line))
	{
		if (line == "" || line.empty())continue;
		token.cur = line;	
		getline(fin, line);
		if (line == "" || line.empty())continue;
		token.line = atoi(line.data());
		getline(fin, line);
		if (line == "" || line.empty())continue;
		token.type = atoi(line.data());
		this->TokenTable.push_back(token);
	}
}

void LEX::ShowNFA()
{
	cout << endl << "Show NFA" << endl;
	vector<string>::iterator k = this->NFA.K.begin();
	vector<string>::iterator e = this->NFA.E.begin();
	vector<string>::iterator z = this->NFA.Z.begin();
	multimap<string, map<string, string>>::iterator f1 = this->NFA.f.begin();
	map<string, string>::iterator f2 = f1->second.begin();
	cout << "Start state:={ " << this->NFA.S << " }" << endl;
	cout << "State set:={ " << *k++;
	while (k != this->NFA.K.end())cout << " ," << *k++;
	cout << " }" << endl;
	cout << "Dictionary set:={ " << *e++;
	while (e != this->NFA.E.end())cout << " ," << *e++;
	cout << " }" << endl;
	cout << "End state set:={ " << *z++;
	while (z != this->NFA.Z.end())cout << " ," << *z++;
	cout << " }" << endl;
	cout << "Mapping:" << endl;
	for (; f1 != this->NFA.f.end(); f1++)
	{
		f2 = f1->second.begin();
		cout << f1->first << " Pass " << f2->first << " To " << f2->second << endl;
	}
}

void LEX::ShowDFA()
{
	cout << endl << "Show DFA" << endl;
	vector<string>::iterator k = this->DFA.K.begin();
	vector<string>::iterator e = this->DFA.E.begin();
	vector<string>::iterator z = this->DFA.Z.begin();
	multimap<string, map<string, string>>::iterator f1 = this->DFA.f.begin();
	map<string, string>::iterator f2 = f1->second.begin();
	cout << "Start state:={ " << this->DFA.S << " }" << endl;
	cout << "State set:={ " << *k++;
	while (k != this->DFA.K.end())cout << " ," << *k++;
	cout << " }" << endl;
	cout << "Dictionary set:={ " << *e++;
	while (e != this->DFA.E.end())cout << " ," << *e++;
	cout << " }" << endl;
	cout << "End state set:={ " << *z++;
	while (z != this->DFA.Z.end())cout << " ," << *z++;
	cout << " }" << endl;
	cout << "Mapping:" << endl;
	for (; f1 != this->DFA.f.end(); f1++ )
	{
		f2 = f1->second.begin();
		cout << f1->first << " Pass " << f2->first << " To " << f2->second << endl;
	}
}

void LEX::ShowTokenTable()
{
	cout << endl << "Token Table" << endl << "Type\tString\t\tLineNum" << endl;
	vector<Token>::iterator it = this->TokenTable.begin();
	for (; it != this->TokenTable.end(); it++)
		cout << it->type << "\t" << it->cur << "\t\t" << it->line << endl;
}



/*

S->aA
S->bB
S->=C
A->@
B->@
C->@

0->@1
1->@2
1->@4
2->a3
3->@6
4->b5
5->@6
6->@1
6->@7
0->@7
7->a8
8->b9
9->bZ
Z->@

D->aZ
D->iI
Z->aZ
Z->iZ
Z->@
I->iI
I->@

S->iI
S->+add
S->-sub
S->*mul
S->/div
S->(lef
S->)rit
S->^exc
I->iI
add->@
sub->@
mul->@
div->@
I->@
rit->@
lef->@
exc->@

*/